package com.example.sagiproject;

public class Level {


        public static final int EASY = 1;
        public static final int HARD = 2;

        private Level() {
            // מונע יצירת אובייקט מהמחלקה
        }


}
