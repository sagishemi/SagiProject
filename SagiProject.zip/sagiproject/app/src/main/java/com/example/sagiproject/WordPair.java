package com.example.sagiproject;

public class WordPair {

        private String english;
        private String hebrew;

        public WordPair(String english, String hebrew) {
            this.english = english;
            this.hebrew = hebrew;
        }

        public String getEnglish() {
            return english;
        }

        public String getHebrew() {
            return hebrew;
        }


}
