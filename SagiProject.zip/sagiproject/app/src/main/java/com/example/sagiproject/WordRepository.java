package com.example.sagiproject;

import java.util.ArrayList;
import java.util.List;

public class WordRepository {

    public List<WordPair> getWordsByLevel(int level) {
        if (level == Level.HARD) {
            return getHardWords();
        } else {
            return getEasyWords();
        }
    }

    private List<WordPair> getEasyWords() {
        List<WordPair> words = new ArrayList<>();

        words.add(new WordPair("apple", "תפוח"));
        words.add(new WordPair("dog", "כלב"));
        words.add(new WordPair("house", "בית"));
        words.add(new WordPair("book", "ספר"));
        words.add(new WordPair("sun", "שמש"));
        words.add(new WordPair("water", "מים"));

        return words;
    }

    private List<WordPair> getHardWords() {
        List<WordPair> words = new ArrayList<>();

        words.add(new WordPair("responsibility", "אחריות"));
        words.add(new WordPair("environment", "סביבה"));
        words.add(new WordPair("achievement", "הישג"));
        words.add(new WordPair("development", "התפתחות"));
        words.add(new WordPair("knowledge", "ידע"));
        words.add(new WordPair("improvement", "שיפור"));

        return words;
    }
}
